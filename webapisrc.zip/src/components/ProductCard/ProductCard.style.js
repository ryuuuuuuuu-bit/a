import React from "react";
import { StyleSheet } from "react-native";


export default StyleSheet.create({

    container: {
        borderWidth: 1,
        borderColor: "#ddddddc2",
        backgroundColor: "#eceff1",
        margin: 10,
        flexDirection: "row",

    },
    Image: {
        width: 100,
        minHeight: 100,
        backgroundColor: "white",
        resizeMode: "contain",
        
    },
    body_container: {
        padding: 10,
        flex: 1,
        justifyContent: "space-between",
    },
    title: {
        fontWeight: "bold",
        fontSize: 18,
    },
    price: {
        textAlign: "right",
        fontSize: 16,
        fontStyle: "italic",
    },
});