import React from "react";
import { View, Text, StyleSheet} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const UserCard = (props) => {
  return (
    <View style={styles.container}>
        <Text style={styles.userName}>{props.username}</Text>
        <View style={styles.userInfo}>
            <Text style={styles.name}>{props.name}</Text>
            <Text style={styles.email}>{props.email}</Text>
            <Text style={styles.phone}>{props.phone}</Text>
        </View>
        

    </View>
  );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#eceff1",
        margin: 5,
        padding: 10,
        borderRadius: 10,
    },
    userName: {
        fontSize: 14,
        fontWeight: "bold",
        marginBottom: 5,
    },
    name: {
        fontSize: 12,
    },
    email: {
        fontSize: 12,
        fontStyle: "italic",
        color: "#555",
        marginLeft: 5
    },
    phone: {
        fontSize: 14,
        color: "#555",
    },
    userInfo: {
        flexDirection: "row",
        alignItems: "center",
    }

})

export default UserCard;