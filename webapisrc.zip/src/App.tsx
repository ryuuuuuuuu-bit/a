import React, { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { View, Text, Button, FlatList, ActivityIndicator } from "react-native";
import axios from "axios";
import UserCard from "./components/UserCard";



const API_URL = "https://jsonplaceholder.typicode.com/users";


function App() {

  const [loading, setLoading] = useState(true);
  const [userList, setUserList] = useState([]);
  // function fetchData() {
  //   const response = axios.get("https://jsonplaceholder.typicode.com/users")
  //   .then(response => console.log(response.data))
  //   .catch(error => console.log(error));
  // }

  async function fetchData() {
    const response = await axios.get(API_URL);
    setLoading(false);
    setUserList(response.data);
  }

  const renderUser = ({ item }: any) => <UserCard username={item.username} name={item.name} email={item.email} phone={item.phone} />

  useEffect(() => {
    fetchData();
  }, [])


  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1 }}>
        {

          loading ? (<ActivityIndicator size="large" />) :
            (<FlatList
              data={userList}
              renderItem={renderUser}
            />)
        }

        {/* <Button title="Fetch Data" onPress={fetchData} /> */}
      </View>
    </SafeAreaView>
  );
}

export default App;