import React from "react";
import { View, Text } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {createNativeStackNavigator} from "@react-navigation/native-stack";
import { NavigationContainer } from "@react-navigation/native";


import DetailScreen from "./pages/Detail";
import ProductsScreen from "./pages/Products/Products";


const Stack = createNativeStackNavigator();



const Router = () => {
    return(
        <NavigationContainer>
            <Stack.Navigator screenOptions={{headerShown: false}}>
                <Stack.Screen name="Product Screen" component={ProductsScreen} />
                <Stack.Screen name="Detail Screen" component={DetailScreen} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}

export default Router;