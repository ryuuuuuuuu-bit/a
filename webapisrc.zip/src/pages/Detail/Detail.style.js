import React from "react";
import {StyleSheet, Dimensions} from "react-native";

const deviceSize = Dimensions.get("window");

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  bodyContainer: {
    padding: 20,
    justifyContent: "space-between",

  },
  image: {
    width: deviceSize.width,
    height: deviceSize.height / 3,
    marginBottom: 20,
    resizeMode: "contain",
    backgroundColor: "#e0e0e0",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  desc: {
    fontSize: 16,
    color: "#666",
    fontStyle: "italic",
    marginBottom: 10,
  },
  price: {
    fontSize: 18,
    color: "#ff5722",
    fontWeight: "bold",
    textAlign: "right",
  },
});