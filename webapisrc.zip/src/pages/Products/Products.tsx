import React, { useState, useEffect } from "react";
import { View, Text, FlatList, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { styles } from "./Products.style";
import Config from "react-native-config";
import axios from "axios";
import useFetch from "../../hooks/useFetch";
import Loading from "../../components/Loading";
import Error from "../../components/Error";

import ProductCard from "../../components/ProductCard";

const Products = ({navigation}:any) => {
    const {loading, data, error} = useFetch(Config.API_URL );

    const handleProductSelect = (id:any) => {
        navigation.navigate("Detail Screen", {id});
    };

    const renderProduct = ({ item }:any) => (
    <ProductCard product={item} onSelect={() => handleProductSelect(item.id)} />
);

    if (loading) {
        return (
                <Loading />
        );
    }

    if (error) {
        return <Error />;
    }

    return (
        <SafeAreaView style={styles.container}>
            <FlatList data={data} renderItem={renderProduct} />
        </SafeAreaView>
    );
}; 

export default Products;