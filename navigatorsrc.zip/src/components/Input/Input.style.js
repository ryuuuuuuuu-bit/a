import React from "react";
import { StyleSheet } from "react-native";

export default StyleSheet.create({

    container: {
    margin: 5, 
        
  },
  input_container: {
    margin: 5,
    borderWidth:1,
    padding: 5,
    borderRadius: 10,
    borderColor: "#bdbdbd",
  },
  label: {
    fontSize: 15,
    fontWeight: "bold",
    marginLeft: 5,
    fontWeight: "bold",
  },
   
});