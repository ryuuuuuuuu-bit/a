import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Button from "../../components/Button";

function Member({navigation}: any) {
  return (
    <View style={styles.container}>
      <Text>Member</Text>
      <Button text="Go to Member Detail" onPress={() => navigation.navigate('MemberDetailScreen')} />
      <Button text="Go to Member Update" onPress={() => navigation.navigate('MemberUpdateScreen')} />
      <Button text="Go to Profile" onPress={() => 
    navigation.navigate('Profile', {screen: 'ProfileEditScreen' })
  } />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Member;