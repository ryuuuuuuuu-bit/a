import React from "react";
import { View, Text } from "react-native";

function MemberUpdate() {
  return (
    <View>
      <Text>Member Update</Text>
    </View>
  );
}

export default MemberUpdate;