import React from "react";
import { View, Text } from "react-native";
import Button from "../../components/Button";

function MemberDetail({navigation}: any) {
  return (
    <View>
      <Text>Member Detail</Text>
      <Button text="Go to Member Update" onPress={() => navigation.navigate('MemberUpdateScreen')} />
    </View>
  );
}

export default MemberDetail;