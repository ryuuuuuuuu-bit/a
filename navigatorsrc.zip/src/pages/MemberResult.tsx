import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";


function MemberResult({ route }: any) {

    const { userObj } = route.params;

    console.log(route);
    return (
        <SafeAreaView style={{ flex: 1, margin: 10 }}>
            <Text style={styles.label} >Üye adı: {userObj.userName}</Text>
            <Text style={styles.label} >Üye soyadı: {userObj.userSurname}</Text>
            <Text style={styles.label} >Üye yaşı:{userObj.userAge}</Text>
            <Text style={styles.label} >Üye epostası:{userObj.userEmail}</Text>
            <Text style={styles.label} >Üye memleketi:{userObj.userHomeTown}</Text>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    label: {
        fontSize: 20,
        fontWeight: "bold",
        marginBottom: 10,
    }
});

export default MemberResult;

