import React, {useState} from "react";
import { View, Text, Alert } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Input from "../components/Input";
import Button from "../components/Button"




function MemberSign({navigation}: any) {

    const [userName, setUserName] = useState("");
    const [userSurname, setUserSurname] = useState("");
    const [userAge, setUserAge] = useState("");
    const [userEmail, setUserEmail] = useState("");
    const [userHomeTown, setUserHomeTown] = useState("");

    function handleSubmit() {

        if (
            !userName ||
            !userSurname ||
            !userAge ||
            !userEmail ||
           !userHomeTown
        ) {
            Alert.alert("Kebap Fitness Salonu", "Lütfen tüm alanları doldurun.");
            return;
        }
        const user = {
            userName,
            userSurname,
            userAge,
            userEmail,
            userHomeTown,
        }
        
        navigation.navigate("MemberResultScreen", {userObj: user});
    }

  return (
    <SafeAreaView style={{flex: 1, margin: 10}}>
        <Input label= "Üye Adı" placeholder="Üye İsmini Giriniz" onChangeText={setUserName}/>
        <Input label= "Üye Soyadı" placeholder="Üye Soyadını Giriniz" onChangeText={setUserSurname}/>
        <Input label= "Üye Yaşı" placeholder="Üye Yaşını Giriniz" onChangeText={setUserAge}/>
        <Input label= "Üye E-posta Adresi" placeholder="Üye E-postasını Giriniz" onChangeText={setUserEmail}/>
        <Input label= "Üye Memleketi" placeholder="Üye Memleketi Giriniz" onChangeText={setUserHomeTown}/>
        <Button text="Kayıt Ol" onPress={handleSubmit} />
    </SafeAreaView>
  );
}

export default MemberSign;