import React from "react";
import { View, Text } from "react-native";

function ProfileEdit() {
  return (
    <View>
      <Text>Profile Edit</Text>
    </View>
  );
}

export default ProfileEdit;