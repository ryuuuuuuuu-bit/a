import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import { StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";


import Welcome from "./pages/Welcome";
import MemberSign from "./pages/MemberSign";
import MemberResult from "./pages/MemberResult";
import Product from "./pages/Product";
import Favorites from "./pages/Favorites";
import Profile from "./pages/profile/Profile";
import Member from "./pages/member/Member";
import { SearchBar } from "react-native-screens";
import MemberDetail from "./pages/member/MemberDetail";
import MemberUpdate from "./pages/member/MemberUpdate";
import ProfileEdit from "./pages/profile/ProfileEdit";

const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

const MemberStack = () => { 
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MemberScreen" component={Member} />
      <Stack.Screen name="MemberDetailScreen" component={MemberDetail} />
      <Stack.Screen name="MemberUpdateScreen" component={MemberUpdate} />
    </Stack.Navigator>
  );
};


const ProfileStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ProfileScreen" component={Profile} />
      <Stack.Screen name="ProfileEditScreen" component={ProfileEdit} />
    </Stack.Navigator>
  );
}
 

function Router() {
  return (
      <NavigationContainer >
      <Tab.Navigator screenOptions={{ headerShown: false }}>
        <Tab.Screen name="Member" component={MemberStack} />
        <Tab.Screen name="Profile" component={ProfileStack} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}




export default Router;

